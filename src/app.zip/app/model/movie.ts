export class Movie{
  Title: string;
  Year: number;
  Poster:string;
  imdbID:string;
}
